---
title: Choose an interface
description: Choose between Agent integrations, the CLI, Python SDKs, HTTP, and MCP.
---

# Choose an interface

All remote interfaces operate on the same Server and persistent Artifact storage.

| Interface | Intended use | Start here |
| --- | --- | --- |
| Codex plugin | Cross-session recall and explicit Memory maintenance in Codex | [Configure Codex](../integrations/codex.md) |
| Claude Code plugin | Cross-session recall and Handoff in Claude Code | [Configure Claude Code](../integrations/claude-code.md) |
| DeepSeek Harness plugin | Recall and explicit Memory maintenance in DeepSeek Harness | [Configure DeepSeek Harness](../integrations/dsh.md) |
| Hermes integration | Recall, Memory, and Handoff tools in Hermes | [Configure Hermes](../integrations/hermes.md) |
| OpenClaw plugin | Bounded recall and durable Memory tools in OpenClaw | [Configure OpenClaw](../integrations/openclaw.md) |
| OpenCode plugin | Recall and Memory maintenance in OpenCode | [Configure OpenCode](../integrations/opencode.md) |
| Pi package | Recall, native Memory/Handoff tools, and skills in Pi | [Configure Pi](../integrations/pi.md) |
| WorkBuddy integration | Prompt recall, MCP tools, and Handoff in WorkBuddy | [Configure WorkBuddy](../integrations/workbuddy.md) |
| Pydantic AI adapter | Preview API; no supported standalone install yet | [Adapter status](../integrations/pydantic-ai.md) |
| LangChain middleware | Bounded recall and completed-turn Source capture in `create_agent` | [Install from source](../integrations/langchain.md) |
| LangGraph adapter | Memory tools and bounded recall inside a LangGraph graph | [Install from source](../integrations/langgraph.md) |
| CLI | Setup, diagnostics, Server control, and human Candidate review | [Install and run](../get-started/install-and-run.md) |
| Python Client SDK | Typed asynchronous calls to a running Server | [Install the client role](../get-started/install-and-run.md#install-a-python-role) |
| Core SDK | In-process Source, Artifact, Trigger, and composition contracts | [Python API reference](/en/modules/) |
| HTTP | Service integration from any language | [HTTP API](http-api.md) |
| MCP | Curated Agent tools for Source capture, Memory, work continuity, reports, and Candidate Review | Enabled by the Server at `/mcp` |

## Codex plugin

The powercontext-project-context skill tells Codex when to search, remember, revise, retire, delegate, hand off, acknowledge, or
record an outcome. The prompt hook recalls relevant entries and captures user input as Source evidence. MCP tools
perform explicit operations. The plugin never starts or embeds the Server.

## Work continuity

HTTP, the Python Client, and MCP expose Work Contract creation, Handoff preparation and continuation, acknowledgement,
and Task Outcome recording. A Prepared Handoff is temporary; `commit_handoff` creates a durable Revision. An
acknowledgement can select a prepared or exact Handoff, but `handoff_receipt_ref` accepts only an accepted exact Receipt
for a committed Revision. Claims and checks can be `declared` or `verified` with exact same-scope citations. These
records never grant identity, tool, or execution authority.

```text
create_work_contract
  -> work
  -> handoff_current_work
  -> continue_handoff + acknowledge_handoff
  -> record_task_outcome
```

`create_work_contract` records the objective, scope, completion criteria, authority notes, and consequential open
questions for newly delegated work. `handoff_current_work` captures caller-inspected state and returns a temporary
Prepared Handoff; it does not publish a milestone. Call `commit_handoff` separately when the user wants a durable
milestone.

The receiver calls `continue_handoff` with a prepared, exact, or latest selection. When starting from latest, the
returned exact Revision is shown and inspected before acknowledgement. `acknowledge_handoff` accepts prepared or exact,
never latest. It refuses acceptance when any Handoff evidence is unavailable or when live-state, capability, and
authorization are not all `confirmed`. A receiver can instead record `needs_clarification` or `declined`. The receipt
and its three confirmations are untrusted observations; they grant no identity, tool, or execution authority.

`record_task_outcome` preserves `succeeded`, `partial`, `blocked`, `failed`, `cancelled`, or `unknown` and exact check
states. To cover a committed Handoff result, `handoff_receipt_ref` identifies the active accepted exact Receipt; an
unlinked Outcome in the same scope does not cover it. The operation stores a `task-outcome` Source that existing
Experience incubation can inspect, but does not generate or approve an Experience by itself. Integrations call it only
at a real completion or interruption boundary, not solely because a prompt, Stop event, or Session ended.

Claims and checks are either `declared` with no evidence or `verified` with exact same-scope citations. A readable
citation proves identity and availability, not freshness. Current instructions, live workspace state, capabilities,
and authorization still take precedence over all Work and Handoff records.

For the complete Codex transfer and acknowledgement workflow, see
[Hand off work in Codex](../workflows/handoff-with-codex.md).

Handoff Report is a read-only projection over a Scope selection. `all` includes every Scope, `exact` includes only the
listed Scope IDs, and `subtree` includes an organization root and all descendants. Each included Scope contributes its
latest exact Handoff address or an explicit `no_handoff` result; Parent does not imply Context visibility. Codex fixes
ordinary Agent report reads to the current Session Scope. Explicit HTTP clients may request broader selections.
See [Use Handoff Report](../workflows/use-handoff-report.md) for the report API.

## DeepSeek Harness plugin

The powercontext-project-context skill tells DeepSeek Harness when to search, remember, revise, or retire Memory. Before each model
step the plugin recalls relevant entries and captures user input as Source evidence. Named `pc_*` tools perform explicit
HTTP operations. The plugin never starts or embeds the Server.

## Pydantic AI adapter

The repository contains a preview Pydantic AI adapter with three Memory tools and automatic bounded
`PreparedContext`. It is not currently available as a supported standalone package. Optional capture stores
redacted, bounded visible model and completed tool events, performs checkpoint Flush, and flushes remaining Sources
after the run. MCP needs no adapter package but does not provide automatic context preparation, capture, or Flush.
See [Pydantic AI adapter preview](../integrations/pydantic-ai.md).

## LangGraph adapter

`powercontext-langgraph` connects a LangGraph graph to a running Server through the public Python Client. It supplies
three components: `powercontext_tools()` returns `BaseTool` instances for model-initiated Memory read and write;
`PowerContextRecall` is a node or `pre_model_hook` that prepends one bounded `PreparedContext` as a system message
labelled untrusted historical evidence; and `PowerContextScope` is a dataclass for the graph `context_schema` that
carries the scope and per-run connection overrides. The recall node and tools read the active scope from the LangGraph
runtime and otherwise fall back to `POWERCONTEXT_LANGGRAPH_*` environment settings.

Scope resolution sends an explicit `scope_id`, when configured, to the Server for validation and otherwise uses the
Server default Scope. The adapter does not derive Scope IDs from Git or process paths. `TOKEN` is a bare token that the
Client composes into `Authorization: Bearer`, unlike the `POWERCONTEXT_*_AUTHORIZATION` header used by the Codex,
Claude Code, and DeepSeek Harness plugins. Recall and the tools fail open: on Server unavailability the graph still
reaches its end and the tools return a short unavailable string. The adapter covers Memory read and write and bounded
recall only; automatic capture, checkpointing, and Handoff are out of scope. The adapter deliberately does not
implement `BaseStore`, whose get, upsert-by-key, and delete operations the Memory model does not provide. It never
starts or embeds the Server.

## LangChain middleware

`PowerContextMiddleware` uses LangChain's `AgentMiddleware` API. It injects one bounded PreparedContext into each
current model request without changing agent state. Automatic capture is disabled by default; pass `auto_capture=True`
to capture the latest user message and final plain-text or structured answer as Content Source evidence after a
successful run. Source-to-Memory activation remains a Server responsibility. Recall and capture fail open, and neither
path starts or embeds the Server. Its source is packaged as `powercontext-langchain`, but it is not currently
published on PyPI. The LangGraph adapter remains a separate node-and-tool integration.

## Pi package

The native Pi package supplies the `powercontext-project-context` skill, named `pc_*` Memory and Handoff tools, and `/pc`
diagnostics. Before each normal agent start, it requests one strict, bounded PreparedContext value and independently
captures an eligible user prompt as Source evidence. It does not synchronize Pi transcripts. Recall, capture, and
boundary flushing fail open; explicit durable writes require interactive confirmation.

## CLI

Set `POWERCONTEXT_SCOPE_ID` to an existing ID returned by `create_scope` before running scoped content commands.

```text
powercontext setup [agents...]
powercontext setup codex dsh
powercontext config agent codex dsh --server-url https://memory.example
powercontext config init --output .env
powercontext config show --env-file .env
powercontext config validate --env-file .env
powercontext doctor
powercontext doctor codex dsh
powercontext server run
powercontext server run --env-file .env
powercontext ready
powercontext capabilities
powercontext experience generate --scope-id "$POWERCONTEXT_SCOPE_ID" --source-ref content/SOURCE_ID
powercontext experience list --scope-id "$POWERCONTEXT_SCOPE_ID"
powercontext experience show --scope-id "$POWERCONTEXT_SCOPE_ID" --revision 1 EXPERIENCE_ID
powercontext skill generate --scope-id "$POWERCONTEXT_SCOPE_ID" --origin experience \
  --artifact-ref experience/EXPERIENCE_ID@REVISION
powercontext skill show --scope-id "$POWERCONTEXT_SCOPE_ID" --revision 1 SKILL_ID
powercontext skill export --target codex --scope-id "$POWERCONTEXT_SCOPE_ID" --revision 1 \
  --destination .agents/skills/example-skill SKILL_ID
powercontext external-skill scan --scope-id "$POWERCONTEXT_SCOPE_ID"
powercontext external-skill list --scope-id "$POWERCONTEXT_SCOPE_ID"
powercontext external-skill resolve --scope-id "$POWERCONTEXT_SCOPE_ID" --fingerprint SHA256 EXTERNAL_SKILL_ID
powercontext external-skill import --scope-id "$POWERCONTEXT_SCOPE_ID" --fingerprint SHA256 \
  --mode import EXTERNAL_SKILL_ID
```

All content commands call the configured Server. The optional `server` role adds `powercontext server run`; it does
not create a second content profile inside the CLI.

The `config` group creates, redacts, and validates an explicit environment file. `server run` discovers `.env` in the
current directory; pass `--env-file` to select another file or `--no-env-file` to disable discovery. See
[Configuration](../operate/configuration.md) for precedence and credential-handling rules.

Use `codex`, `claude-code`, `dsh`, `hermes`, `kimi-code`, `openclaw`, `opencode`, `pi`, `workbuddy`, or `zcode` for agents.
`powercontext setup` offers interactive selection; explicit agent names support non-interactive and multi-agent setup.
Setup installs, configures, activates where supported, and runs doctor. Failures remain isolated per agent; completed installation is reported even when diagnostics fail.

`powercontext config agent [agents...]` updates installed connections without reinstalling or enabling plugins.
`powercontext doctor [agents...]` checks the selected agents, or saved connections when none are selected.
With no saved connections, doctor checks the package and Server. Selected agents with a missing required CLI fail their own checks.
Doctor preserves host-specific checks, including OpenCode's separate `plugin` and `skill` results. DSH checks its native registration; Pi checks its registered package.

The unified HTTP review routes are `/v1/candidates/list`, `get`, `history`, `revise`, `approve`, and `reject` (all POST).
`candidate_kind=artifact|tag` distinguishes proposals. Old Artifact Candidate routes are removed; callers must upgrade together.
Artifact approval returns a real revision; Tag approval returns committed tags and ETag without creating a content revision.

Review decisions remain available through MCP. With access control enforced, Server authorization requires
`scope.review`; it does not prohibit an authorized proposer from approving its own Candidate. MCP tool annotations let
hosts apply confirmation policies but do not require human confirmation. See
[Review authority](../workflows/review-candidates.md#review-authority) for access modes and reviewer separation.

The `candidate` command group exposes the human Review Inbox. See [Review Candidates](../workflows/review-candidates.md)
for the ordered workflow to list, inspect, revise, approve, or reject Candidates.

Generation and revision commands accept repeatable `--source-ref TYPE/ID` and
`--artifact-ref FAMILY/ID@REVISION` options instead of serialized request files. `--target FAMILY/ID@REVISION`
automatically includes the target in Artifact evidence. Managed Skill revision accepts exactly one of inline
`--instructions` or `--instructions-file`, and `--validation` can be repeated.

## Python Client SDK

`PowerContextClient` is the typed asynchronous HTTP client for a Server-owned deployment. Its request and response
models are exported from `powercontext.http`. Memory mutation `records` contain real ArtifactRefs, content, and current
state. Content edits use the content ETag; lifecycle operations use the required content and state versions. Exact
history is read as Atomic Memory Artifact revisions. See the [HTTP API lifecycle tutorial](api-quickstart.md) for a runnable client
flow and [Atomic Memory](../workflows/atomic-memory.md) for lifecycle operations.

The Client also exposes `generate_experience`, `propose_experience`, `get_experience`, `generate_skill`,
`propose_skill`, `get_skill`, `scan_external_skills`, `list_external_skills`, `resolve_external_skill`,
`import_external_skill`, and the Candidate Review methods. Review writes require `expected_version`. Approval returns
the exact Experience or managed Skill `result_artifact`; pending and rejected Candidates are not Artifact revisions.

`generate_experience` and `generate_skill` accept caller-selected exact Source and Artifact references. They return
either one pending Candidate or an explicit `no_op`. A replacement includes its exact target in `artifact_refs` and
sets `target`. Managed Skill generation also declares its provenance shape:

- `experience`: at least one approved Experience reference, with optional exact Sources;
- `source`: only exact Source references, including official or human-authored material;
- `usage`: the exact target Skill plus bounded usage Sources.

These generation operations require `POWERCONTEXT_SERVER_INFERENCE_GENERATION_MODEL`. The lower-level `propose_*`
operations remain available for a human or integration that already has complete typed content and exact evidence.
Both paths return pending content; approval is a separate operation. After Review approval, deterministic
`searchable_text` is stored on the existing generic Artifact head and enters the backend's rebuildable FTS index, making the Experience eligible for
`PreparedContext` recall in the same scope. Pending and rejected Candidates, all managed Skills, and historical
Experience revisions remain excluded.

For the relationship between evidence, Candidate versions, approved Revisions, recall, and export, see
[Experience and Skill lifecycle](../workflows/experience-and-skill-lifecycle.md).

## Scheduled Atomic Memory processing

The built-in Source-window schedule compares journal positions with its own persisted consumption cursor before
activating a Scope. Fully consumed journals skip scoped processing, while buffered windows remain eligible on later
ticks without requiring another captured Source. Discovery is advisory: authorization and cursor/window checks
still run in the selected Scope's processing operation, and captures committed after discovery remain visible to
subsequent ticks.

This selection applies to the built-in Source-window policy. A directly assembled Runtime with a custom Scope
selector retains that selector, and Experience incubation uses its independent cursor and schedule.

## Scheduled Experience incubation

An integration can capture a completed task as a Content Source with metadata `"kind": "task-outcome"`. When the
Experience schedule is configured, APScheduler scans bounded Source windows and asks the configured schema-bound
pipeline for reusable situation, action, outcome, and lesson proposals. Each proposal cites exact Sources and enters
the Review Inbox as a pending Experience Candidate.

Experience incubation has its own persisted Source cursor, independent from Memory extraction. Candidate writes and
cursor advancement commit together; a generation or write failure leaves the window available for retry. Ordinary
prompt Sources are not Task Outcomes and are ignored by this job.

Scheduling stops at the review boundary. It never approves an Experience, includes pending content in
PreparedContext, derives a managed Skill, exports a Skill for an Agent target, or executes instructions. Skill authoring and
export remain explicit steps after the supporting Experience is approved.
Setup and verification steps are in
[Create and review an Experience](../workflows/create-and-review-experience.md).

## Managed Skill export to Agent targets

A configured generator can produce complete managed Skill content through `generate_skill`; a human or integration
can submit already-complete typed content through `propose_skill`. The proposal contains a name, discovery
description, instructions, validation checks, and exact Source or Artifact lineage. It remains a Candidate until a
reviewer approves the exact Candidate version.

Approval creates an immutable Skill Revision. It does not install the Skill or grant execution authority. To make one
approved Revision available to Codex or Claude Code, export it explicitly into a configured repository, user, or plugin
Skill target. The projection writes `SKILL.md` and `powercontext.json`; the manifest records the Agent kind, exact
Artifact reference and rendered-content hash. It refuses to replace an existing destination, so updates require an
intentional new export rather than a silent overwrite.

Codex can discover a repository-local export under `.agents/skills/<name>/SKILL.md`. The Artifact Revision remains
the content authority; Claude Code uses `.claude/skills/<name>/SKILL.md` for the equivalent project target. Both
directories are host-local projections that can be rebuilt from the same exact Revision.
See [Create and export a managed Skill](../workflows/create-and-export-skill.md) for the procedure.

## External Agent-native Skills

External Skills remain authoritative in their original local packages. With explicitly configured Agent targets, the
Server can scan a scope-local, rebuildable Registry and report name, description, provider, Agent kind, host,
installation scope, locator, and whole-package fingerprint. Exact resolve succeeds only when the same package remains
readable on the configured host and its fingerprint still matches. It never installs a package or falls back to a
different version.

Discovery does not enter Review. An explicit `import_external_skill` request with the exact identity and fingerprint
captures the validated whole package and records Source evidence for that snapshot. With `mode=import`, the Runtime
proposes the captured package directly, preserving its file paths and bytes, including scripts and resources, without
calling a generation model. With `mode=fork`, a configured generator uses the snapshot as evidence for a new managed
Skill proposal and may return `no_op` without a Candidate. Capturing the original package does not guarantee that the
generated proposal retains its scripts or resources.

When either mode returns a Candidate, it remains pending until Review approval creates a new managed Skill identity.
Neither mode edits the original external package. Later changes that alter the package fingerprint make the old
fingerprint unavailable for resolution or import; they do not replace an already approved managed Revision.

## Authority and gates

| Surface | Content authority | Model gate | Review gate | Current availability |
| --- | --- | --- | --- | --- |
| External Agent-native Skill | Original package | No for scan/list/resolve/import; yes for fork | No for discovery; yes for import/fork Candidates | Host-local Registry and exact resolve |
| Experience | Exact approved Artifact Revision | Yes for generate/evolve; no for typed `propose` | Yes | Exact read and approved-head FTS recall in PreparedContext |
| Managed Skill | Exact approved Artifact Revision | Yes for generate/evolve/fork; no for import or typed `propose` | Yes | Exact read and explicit Agent projection |
| Agent projection | Its source managed Skill Revision | No | No additional review | Rebuildable Codex or Claude Code host-local copy |

## Core SDK

The base `powercontext` package exports Python protocols and models for applications that own their composition root.
It does not select storage, scheduling, transport, or inference on the application's behalf. Use `builtin` when you
want the supplied SQLite or OceanBase-backed implementation in the same process.

## HTTP and MCP

See [HTTP API](http-api.md) for authentication, curl examples, operation groups, errors, and the complete OpenAPI
contract. The Server publishes a Scalar API reference at `/docs`, its OpenAPI document at `/openapi.json`, readiness at
`/health/ready`, capabilities at `/v1/capabilities`, and Streamable HTTP MCP at `/mcp` by default. The Scalar reference
remains public when bearer authentication is enabled, but the operations it describes retain their normal authentication
requirements. HTTP is the complete application contract. MCP is a curated Agent-facing projection of Source capture,
Memory maintenance, work continuity, scope Handoff Report lookup, and Candidate Review. The six Candidate Review
operations use the same validation, `expected_version` concurrency checks, and approval transaction over HTTP and MCP.
Readiness is `ready` with HTTP 200 when all checks pass, `degraded` with HTTP 200 when only configured inference checks
fail, and `not_ready` with HTTP 503 when the Runtime or database fails. Dependency checks use `ready`, `unavailable`,
`timeout`, or `misconfigured`; an intentionally unbound Runtime reports `not_ready` for the `runtime` check.
Experience and Skill generation, exact reads, external Registry operations, and low-level proposal operations remain
HTTP-only.

MCP uses stateless Streamable HTTP and does not issue MCP session IDs. When authentication is enabled, each
request uses its own verified identity and current group membership. Scopes, Memory, and Handoffs remain
persisted in the Runtime. Reconnect MCP clients after upgrading; cross-request SSE stream resumption is
unavailable.

`POST /v1/context/prepare` and the matching Python Client method expose final ephemeral `PreparedContext` over HTTP;
the Runtime recalls active Memory and approved Experience heads, owns their shared selection and total output budget,
and intentionally does not project the operation as an MCP tool. The public schema remains
`powercontext.prepared-context.v1`; Experience items carry an exact Artifact reference inside the prepared content.
