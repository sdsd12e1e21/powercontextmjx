---
title: Troubleshooting and recovery
description: Diagnose PowerContext installation, Server, database, and host integration problems.
---

# Troubleshooting and recovery

Start with:

```bash
powercontext doctor
```

The command checks saved agents and their Servers, or the package and Server when no agents are saved. It exits 1 unless every check is
`ok`; a `degraded` readiness result is usable but is not a complete diagnostic success. Add `--json` for automation;
JSON includes the overall `ok` result and individual diagnostic statuses. Select host integrations explicitly:

```bash
powercontext doctor codex dsh
powercontext doctor codex
powercontext doctor claude-code
powercontext doctor dsh
powercontext doctor openclaw
powercontext doctor opencode
powercontext doctor pi
powercontext doctor hermes
```

`doctor` checks saved agent connections by default, falling back to package and Server checks when none are saved.
Explicit names select the agents to check. A missing required CLI or unhealthy agent makes the command exit 1;
other selected agents still receive their own results.

## Installation cannot read the Git URL

Confirm that Git can read the repository:

```bash
git ls-remote https://github.com/oceanbase/powercontext.git refs/heads/master
```

If this fails, configure the credential helper or SSH key used by Git, then rerun `uv tool install`. `uv` uses Git's
credential configuration; PowerContext does not accept or store repository credentials.

## A PowerContext or host CLI is not found

Run:

```bash
uv tool dir --bin
command -v powercontext
command -v codex
command -v claude
command -v dsh
command -v openclaw
command -v opencode
command -v pi
command -v hermes
```

Add the uv tool bin directory to `PATH` if needed. `powercontext setup codex`, `powercontext setup claude-code`,
`powercontext setup dsh`, `powercontext setup openclaw`, `powercontext setup opencode`, `powercontext setup pi`, and
`powercontext setup hermes` report an error rather than attempting installation when the host CLI is unavailable.
`powercontext setup codex dsh` installs only the hosts you choose. A selected host that is missing still fails that row
and does not block the other selected hosts. An unselected host is skipped even if its CLI is on `PATH`.

## The plugin is missing or stale

Confirm the integration failure without involving the Server:

```bash
powercontext doctor codex
powercontext doctor dsh
powercontext doctor pi
```

Reinstall it from the same ref as the tool:

```bash
powercontext setup codex
codex plugin list --json
```

Then start a new Codex session. Check `/hooks` if prompt recall and capture do not run.

For Claude Code, run:

```bash
powercontext doctor claude-code
powercontext setup claude-code
claude plugin list --json
```

Then start a new Claude Code session. Check `/hooks` and `/mcp`; the plugin inventory should contain one
`UserPromptSubmit` Hook and one `powercontext` MCP Server.

If setup fails while creating new user-scoped objects, it attempts to remove only the plugin and Marketplace entries
created by that invocation. Existing entries are preserved. Correct the reported Claude CLI or repository error and
rerun the same setup command.

For DeepSeek Harness, run:

```bash
powercontext doctor dsh
powercontext setup dsh
dsh --profile web --dump-config
```

Then start a new DeepSeek Harness session and confirm dump-config lists `id: powercontext-dsh`. The DSH plugin
directory must contain `lib/index.js`.

For Pi, run:

```bash
powercontext doctor pi
powercontext setup pi
pi list
```

Then start a new Pi session and confirm `pi list` includes the PowerContext package source.

## The Server check fails

Start the service:

```bash
powercontext server run
```

If port 8000 is already in use, stop the conflicting process. For a different Server endpoint, pass its
base URL when checking it:

```bash
powercontext doctor --server-url http://127.0.0.1:9000
powercontext --server-url http://127.0.0.1:9000 ready
```

The bundled Codex and Claude Code plugins and Pi package use port 8000 by default. A liveness failure means the process
cannot answer health requests, so readiness is not checked. `not_ready` with HTTP 503 means the Runtime or database cannot accept work.
`degraded` with HTTP 200 means a configured inference capability failed while database-backed operations remain
available. Human and JSON output retain the Server's individual check statuses.

Automation should not check only the exit code of `powercontext ready`: when the Server returns HTTP 200 with
`degraded`, the `ready` command can still exit 0. Check the top-level JSON `status` instead:

```bash
powercontext --json ready | jq -e '.status == "ready"' >/dev/null
```

The command exits nonzero when `status` is `degraded`. To have PowerContext itself fail on a degraded result, use
`powercontext doctor --json`; it exits nonzero unless the complete diagnostic result is `ok`.

### Permissions for metrics and capabilities

In `enforced` mode, the Authentication Provider builds a Principal from the request credentials. A valid Bearer token
only authenticates the request; it does not automatically grant every permission.

Both `/metrics` and `/v1/capabilities` require the Server-level `server.observe` permission. Requests therefore return:

- HTTP 401 when no valid authentication credentials are supplied;
- HTTP 403 when the Principal is authenticated but lacks `server.observe`.

With the built-in static Bearer token, check metrics with:

```bash
export POWERCONTEXT_DEPLOYMENT_TOKEN="your-token"

curl --fail \
  --header "Authorization: Bearer ${POWERCONTEXT_DEPLOYMENT_TOKEN}" \
  http://127.0.0.1:8000/metrics
```

You can check the Server's advertised capabilities in the same way:

```bash
curl --fail \
  --header "Authorization: Bearer ${POWERCONTEXT_DEPLOYMENT_TOKEN}" \
  http://127.0.0.1:8000/v1/capabilities
```

See [Server authentication and permissions](configuration.md#server) for Principal, access-control, and Bearer token configuration.

## Local tracing examples and existing Server configuration

The local Phoenix and Langfuse tracing examples are written for an isolated test instance and default to loopback
addresses. Dashboard follows the Server access mode: local access with `ACCESS_MODE=disabled` requires no token and
leaves `AUTH_TOKEN` unset; `ACCESS_MODE=enforced` requires a valid static token.

When an existing Server already uses static Bearer authentication, keep its authentication configuration while adding
tracing. If you also enable the Dashboard, use the same static Bearer configuration:

```dotenv
POWERCONTEXT_SERVER_DASHBOARD_ENABLED=true
POWERCONTEXT_SERVER_ACCESS_MODE=enforced
POWERCONTEXT_SERVER_AUTH_TOKEN=<valid-token>
```

Do not clear authentication variables to bypass a startup error.

If you need an isolated unauthenticated test instance, use a separate environment configuration such as:

```dotenv
POWERCONTEXT_SERVER_DASHBOARD_ENABLED=false
POWERCONTEXT_SERVER_ACCESS_MODE=disabled
POWERCONTEXT_SERVER_HTTP_HOST=127.0.0.1
```

Unauthenticated mode is suitable only for a local test environment bound to loopback. Configure a remote or existing
Server according to [Deploy the Server](deploy-server.md).

## The Server cannot open its database

The database is created when the Server starts, not when the tool is installed. Inspect the Server startup error before
rerunning `powercontext doctor`.

To use a controlled location:

```bash
export POWERCONTEXT_HOME=/path/with/write/access
powercontext server run
```

Use the same environment variable whenever you start or diagnose that instance. PowerContext creates missing parent
directories for a file-backed SQLite database.

## Processing state requires maintenance

If startup reports that the processing schema is not ready, follow
[Migrate Artifact processing state](artifact-processing-migration.md). Existing
Topic Pending, Cursor and accepted calls need explicit migration before the new
Supervisor starts. Do not remove the old processing tables to bypass this check.

## OceanBase startup rejects an incompatible schema

Current PowerContext releases compare opaque identity columns byte-for-byte with `utf8mb4_bin`. A database created by
an older release may still use a case-insensitive collation such as `utf8mb4_general_ci`. The Server checks existing
identity columns before creating any missing tables and refuses to start when it finds a mismatch. The startup error
lists each affected `table.column`, its actual collation, and the required collation; it never includes the database
URL or credentials.

Do not alter these columns in place. They participate in primary keys, foreign keys, and indexes, and an earlier
case-insensitive deployment may already have treated distinct identities as the same value. Use a new empty database
so the previous database remains available for recovery:

1. Stop the Server and every process that writes to the database.
2. Take and verify a full recoverable backup using your normal OceanBase backup procedure.
3. Export the PowerContext table data with OceanBase `obdumper` in CSV or SQL data mode **without `--ddl`**. Keep the
   export and the original database unchanged until the migration is verified. Supply credentials through your
   approved secret-handling process rather than placing them in logs or documentation.
4. Create a new empty OceanBase MySQL-mode database and point `POWERCONTEXT_SERVER_DATABASE_URL` at it. Start the
   current PowerContext version once to create tables with `utf8mb4_bin`, then stop it before restoring data.
5. Import only the exported row data into the existing new tables with OceanBase `obloader`, again **without
   `--ddl`**. Keep foreign-key enforcement enabled and run these four layers separately. The examples use CSV; if
   you exported SQL data, replace `--csv` with `--sql` in all four commands. Fill in `<connection-options>` through
   your approved secret-handling process and make `<new-database>` select the database created in step 4.

   Before running the commands, compare the exported table files with `SHOW TABLES` in the target database. Every
   exported table named below must exist in the target; if one is missing, stop and create it with the current
   PowerContext configuration before importing. Remove a name only when the source export does not contain that table.
   Because `pc_scopes.parent_scope_id` is self-referential, keep ancestor Scope rows before their descendants in the
   exported `pc_scopes` data.
   If the source predates the three Skill lifecycle tables (`pc_skill_packages`, `pc_agent_skill_targets`, and
   `pc_skill_publications`), the Profile tables, `pc_topic_memory_work_budgets`, `pc_topic_memory_work_blocks`,
   `pc_recall_effort_daily`, `pc_receipt_migration_review`, `pc_context_bootstrap_receipts`, or
   `pc_decision_observations`, remove the absent tables from their respective layers.
   When a work-budget table exists, restore it together with Cursors so failure allowances survive the migration.
   Restore work-attempt records as well to preserve block identities, diagnostics and accepted retry receipts.

   Layer 1 contains parents and tables without foreign keys:

   ```bash
   obloader <connection-options> -D <new-database> --csv \
      --table 'pc_scopes,pc_source_journal_heads,pc_sources,pc_artifacts,pc_portable_restore_receipts,pc_source_cursors,pc_memory_source_windows,pc_artifact_processing_leases,pc_artifact_processing_binding_states,pc_artifact_processing_pending,pc_artifact_processing_auto_wave_targets,pc_artifact_processing_sequences,pc_artifact_processing_intents,pc_topic_memory_processing_targets,pc_artifact_processing_schema,pc_artifact_processing_migration_receipts,pc_topic_memory_work_budgets,pc_topic_memory_work_blocks,pc_topic_memory_retrieval_shape,pc_connector_checkpoints,pc_source_definition_manifests,pc_external_skill_registrations,pc_skill_packages,pc_agent_skill_targets,pc_skill_publications,pc_model_usage_daily,pc_recall_token_daily,pc_recall_effort_daily,pc_receipt_migration_review,pc_decision_observations,pc_lexical_projection_versions' \
     -f <export-directory>
   ```

   After Layer 1 completes successfully, import its children in Layer 2:

   ```bash
   obloader <connection-options> -D <new-database> --csv \
     --table 'pc_dream_runs,pc_context_bootstrap_receipts,pc_scope_context_references,pc_scope_external_references,pc_scope_creation_requests,pc_scope_settings,pc_scope_bindings,pc_artifact_handles,pc_artifact_heads,pc_artifact_lineage_sources,pc_artifact_lineage_artifacts,pc_artifact_publications,pc_candidate_versions,pc_topic_memory_revision_publications,pc_memory_entry_versions' \
     -f <export-directory>
   ```

   After Layer 2 completes successfully, import the remaining children in Layer 3:

   ```bash
   obloader <connection-options> -D <new-database> --csv \
      --table 'pc_candidate_heads,pc_topic_memory_active_topics,pc_topic_memory_active_chunks,pc_memory_entry_heads,pc_artifact_tags,pc_recurrence_match,pc_recurrence_observation' \
     -f <export-directory>
   ```

   After Layer 3 completes successfully, import Profile policy in Layer 4:

   ```bash
   obloader <connection-options> -D <new-database> --csv \
     --table 'pc_profile_policies' \
     -f <export-directory>
   ```

   Wait for each invocation to complete successfully before starting the next. Treat any OBLoader error, bad record,
   or conflict record as a failed restore. Order within a layer is irrelevant because no table in a layer references
   another table in the same layer.
6. If the installation has additional PowerContext-managed tables not listed above, these tested layers do not
   classify them. Inspect their foreign-key constraints and place each table after all of its parents; do not add
   them to an all-table invocation.
7. Compare source and target row counts for every restored table, inspect the identity-column collations, and test
   identities that differ only by case or accent. Start normal traffic only after every check passes. Retain the
   source database, verified backup, and export through the rollback window.

If records were previously merged because the old collation considered their identities equal, changing the schema
cannot reconstruct them. Resolve those records from an authoritative source before accepting writes.

## An inference readiness check fails

When generation or embedding is configured, Server readiness makes one minimal real provider request. This catches
credentials and endpoints that can be validated only by sending a request, including a base URL that is missing the
provider's API prefix. Stable statuses are `ready`, `unavailable`, `timeout`, and `misconfigured`; responses never
include credentials, provider response bodies, or configured URLs.

An inference failure makes overall readiness `degraded` with HTTP 200 instead of removing the whole Server from
traffic. `ready` and `misconfigured` results are cached for 300 seconds; temporary `timeout` and `unavailable` results
are retried after 30 seconds. Concurrent health requests share one refresh. Restart the Server to apply corrected
static configuration immediately, or wait for the cached result to expire.

## Memory writes work but captured prompts do not become Memory

Explicit Memory operations do not require a model. Converting captured Source evidence into Memory does. Configure a
generation model and its provider credentials, then either enable the scheduler or flush the scope explicitly. Check
the Server's advertised behavior:

```bash
powercontext capabilities
```

`Memory extraction: disabled` means the Server has no generation model.

## Host-visible integration diagnostics

The Codex, Claude Code, DSH, OpenClaw, Pi, and Hermes integrations are fail-open: a PowerContext outage does not
block the host task. They also expose a bounded, content-free diagnostic through the host's supported channel:

| Host | Diagnostic channel | Component |
| --- | --- | --- |
| Codex | Hook stdout `systemMessage` | `powercontext.codex.recall` |
| Claude Code | Hook stdout `systemMessage` | `powercontext.claude_code.recall` |
| DSH | Host logger warning | `powercontext.dsh` |
| OpenClaw | Plugin logger warning | `powercontext.openclaw` |
| Pi | Host terminal warning | `powercontext.pi` |
| Hermes | Python host logger warning | `powercontext.hermes` |

For example, a transport failure is returned in the hook's top-level `systemMessage`; its value is a single-line,
content-free JSON event such as:

```json
{"systemMessage":"{\"component\":\"powercontext.codex.recall\",\"event\":\"context_prepare\",\"outcome\":\"server_unavailable\",\"recovery\":\"powercontext doctor\"}"}
```

The stable outcomes remain distinct: `authentication_failed`, `version_mismatch`, `server_unavailable`, and
`invalid_response`. Diagnostics never include prompts, recalled content, scopes, URLs, credentials, response bodies,
or exception text. Repeated outcomes are deduplicated within one invocation and throttled for 60 seconds using local
state shared across hook processes; a diagnostic failure never changes the host task result.

Bub is not included in this first host-diagnostic slice. Its integration will be qualified separately when its host
diagnostic channel and native lifecycle behavior are specified.

## The coding agent continues when the Server is down

This is expected. The supported integrations fail open so a Memory outage cannot block ordinary work. Inspect the
host-visible diagnostic and run `powercontext doctor`; restart the Server to restore recall and capture. The existing
database is reopened automatically.

## Codex does not inject recalled context

For failures, inspect the Hook's top-level `systemMessage`; its value is the single-line JSON event. `empty` means the
Runtime prepared no context for this turn and remains a local diagnostic rather than a host warning.
`version_mismatch` means the installed plugin expects
`POST /v1/context/prepare` but the Server does not provide it—reinstall the plugin and tool from the same ref, then
restart the Server. `server_unavailable` and `invalid_response` distinguish transport and contract failures. These
events intentionally omit the query and prepared content.

Run `powercontext capabilities` and confirm that `powercontext.prepared-context.v1` appears under Context
versions.

## Claude Code does not inject recalled context

First separate installation from Server health:

```bash
powercontext doctor claude-code
powercontext doctor
```

The first command checks the Claude CLI and enabled plugin without contacting the Server. The second checks Server
liveness and readiness. For failures, inspect the Hook's top-level `systemMessage`; its value is the single-line JSON
event. Claude Code uses the same Prepared Context
contract as Codex, with component `powercontext.claude_code.recall`:

| Outcome | Action |
| --- | --- |
| `empty` | No relevant Memory was prepared; no action is required |
| `authentication_failed` | Export the complete `POWERCONTEXT_CLAUDE_AUTHORIZATION` header before starting Claude Code |
| `version_mismatch` | Install the package and plugin from the same ref, then restart both processes |
| `server_unavailable` | Start the Server or correct `POWERCONTEXT_CLAUDE_SERVER_URL` |
| `invalid_response` | Check for a proxy, redirect, incompatible schema, malformed JSON, or an oversized response |

The diagnostics never log the token, query, scope, prepared content, or response body. Prompt capture is independent
of recall; a capture failure cannot suppress valid context, and a recall failure cannot suppress capture.

## Claude Code MCP authentication fails

The Hook reads `POWERCONTEXT_CLAUDE_AUTHORIZATION` from the environment that starts Claude Code, and the MCP
configuration expands the same value into its `Authorization` header. Stop the current process, export the complete
header, and start it again:

```bash
export POWERCONTEXT_CLAUDE_AUTHORIZATION="Bearer $POWERCONTEXT_LOCAL_TOKEN"
claude
```

Do not add the token to `.mcp.json`, the Server URL, or plugin options. Use `/mcp` after restart to confirm that the
`powercontext` Server is connected.

## Pi does not inject recalled context

First check the package and Server separately:

```bash
powercontext doctor pi
powercontext doctor
```

Restart Pi after installing the package or changing `POWERCONTEXT_PI_*` variables. In a new Pi session, run
`/pc doctor` to check the configured Server directly. Recall is fail-open and reports a content-free host terminal
warning when the Server is unavailable, redirects, times out, or returns an invalid PreparedContext; Pi continues
without adding context. Restore the Server, then run `powercontext capabilities` and confirm that Context versions lists
`powercontext.prepared-context.v1`.

## MySQL driver compatibility and binary Source writes

The built-in dependencies constrain PyMySQL to `>=1.2,<1.2.1` while aiomysql 0.3.2 is in use.
This applies to both OceanBase and embedded seekdb. PyMySQL 1.2.1 and 1.2.2 break aiomysql imports;
1.2.3 imports successfully but fails when aiomysql encodes bytes, including stored Source payloads.
Reinstall or synchronize the complete PowerContext dependency set instead of upgrading PyMySQL independently.
The `database: ready` probe runs `SELECT 1`; it does not verify binary writes or write permissions.

This is a temporary compatibility restriction, not a general recommendation to downgrade PyMySQL.
[PyMySQL 1.2.1](https://github.com/PyMySQL/PyMySQL/blob/main/CHANGELOG.md) fixes SQL injection involving
bytes and surrogate-escaped strings with big5, gbk, sjis, cp932, and gb18030. PowerContext requires
`charset=utf8mb4` for OceanBase and constructs seekdb connections with `utf8mb4`, so these supported
profiles do not select the affected legacy character sets. This assessment does not cover custom
connections, session charset changes, or other applications sharing the environment, and is not a
claim that the older driver is free of other vulnerabilities. Use an isolated environment and retain
the required charset. Remove this restriction only after the async driver supports the updated
binary encoding and Source write/read/replay tests pass against both backends.

## Memory extraction repeatedly times out

A generation timeout leaves the Memory Source cursor unchanged. The Memory processor halves the
failed journal window for the next attempt, down to one position. The reduced limit is stored per
Scope and survives Worker replacement and Server restart; it never exceeds `SOURCE_WINDOW_LIMIT`
or an explicit flush limit. Each invocation makes one extraction attempt, so Supervisor backoff and
Worker deadlines continue to bound retries. The reduction is retained while consuming the backlog
visible at the timeout and cleared atomically when that backlog is consumed.

The processor never skips failed Sources or acknowledges a failed invocation. A single Source can
still time out, and an unavailable provider, embedding failure, or hard Worker termination does not
trigger this generation-timeout recovery. Other Scopes continue independently. Inspect the
`memory.window_reduced` log event and the provider error; if one Source still fails, adjust the model
or generation timeout and retry. Keep the Worker timeout above the model request timeout plus
startup and commit overhead so the processor can record a reduction before the Worker is stopped.
