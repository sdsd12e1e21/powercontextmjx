---
status: community
title: WorkBuddy
description: Install the PowerContext WorkBuddy hooks and control its local behavior.
---

# WorkBuddy

`community`

## Prerequisites

- A running PowerContext installation. Install the CLI and local Server from the same `master` revision used below:
  `uv tool install --force "powercontext[cli,server] @ git+https://github.com/oceanbase/powercontext.git@master"`.
  Start the Server with `powercontext server run`.
- WorkBuddy with user-level hooks, MCP, and Skills support (the desktop app).
- Python 3.11 or newer on `PATH` for the hook process.
- The plugin directory from this repository: `integrations/workbuddy/plugins/powercontext`.

The integration does not start or embed the Server; it only talks to a running
PowerContext Server over HTTP.

## Install with the PowerContext CLI

WorkBuddy supports `setup workbuddy`, `config agent workbuddy`, and `doctor workbuddy`, including multi-agent commands.

The CLI installs the hooks, MCP server, and Skill from a local checkout or a
GitHub source in one step:

```bash
powercontext setup workbuddy
```

For a local checkout, point `--source` at the repository root or the plugin
directory:

```bash
powercontext setup workbuddy --source /path/to/powercontext
```

The installer writes the hook driver and scope resolver to `~/.workbuddy/hooks`,
merges the `UserPromptSubmit` hook into `~/.workbuddy/settings.json`, registers
the `powercontext` server in `~/.workbuddy/mcp.json`, and installs the
`powercontext-project-context` Skill under `~/.workbuddy/skills`. Existing settings and other
MCP servers are preserved, and the Skill's command placeholders are resolved
automatically.

Verify the installation with:

```bash
powercontext doctor workbuddy
```

Then keep the Server running and restart WorkBuddy:

```bash
powercontext server run
```

## Manual installation (alternative)

You can also install the plugin manually. The examples use `~/.workbuddy/hooks`
as the WorkBuddy hooks directory; replace it with your own location and use the
same value wherever `<WORKBUDDY_HOOKS_DIR>` appears below.

### 1. Copy the plugin files

```bash
PLUGIN=integrations/workbuddy/plugins/powercontext
WORKBUDDY_HOOKS_DIR="${WORKBUDDY_HOOKS_DIR:-$HOME/.workbuddy/hooks}"

mkdir -p "$WORKBUDDY_HOOKS_DIR"
cp "$PLUGIN"/hooks/workbuddy_powercontext_hook.py \
   "$PLUGIN"/hooks/workbuddy_settings.py \
   "$PLUGIN"/hooks/powercontext_client_config.py \
   "$PLUGIN"/hooks/prepared_context.py \
   "$PLUGIN"/hooks/prompt_privacy.py \
   "$WORKBUDDY_HOOKS_DIR"/
cp "$PLUGIN/scripts/workspace_scope.py" \
   "$WORKBUDDY_HOOKS_DIR/powercontext_scope_binding.py"
```

### 2. Register the hook

Merge the following `hooks` block into `~/.workbuddy/settings.json`. Replace
`<POWERCONTEXT_PYTHON>` with the Python executable that can import PowerContext,
and `<WORKBUDDY_HOOKS_DIR>` with the absolute path of your hooks directory; the
command string cannot expand environment variables.

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "\"<POWERCONTEXT_PYTHON>\" \"<WORKBUDDY_HOOKS_DIR>/workbuddy_powercontext_hook.py\"",
            "timeout": 30,
            "statusMessage": "Syncing PowerContext"
          }
        ]
      }
    ]
  }
}
```

### 3. Register the MCP server

Merge the following `mcpServers` entry into `~/.workbuddy/mcp.json`:

```json
{
  "mcpServers": {
    "powercontext": {
      "type": "http",
      "url": "${POWERCONTEXT_WORKBUDDY_SERVER_URL:-http://127.0.0.1:8000}/mcp",
      "headers": {
        "Authorization": "${POWERCONTEXT_WORKBUDDY_AUTHORIZATION:-}"
      },
      "description": "PowerContext agent memory & handoff MCP server (local service on port 8000)"
    }
  }
}
```

### 4. Install the Skill

```bash
mkdir -p ~/.workbuddy/skills
cp -R integrations/workbuddy/plugins/powercontext/skills/powercontext-project-context \
  ~/.workbuddy/skills/
cat > ~/.workbuddy/skills/powercontext-project-context/.powercontext.json <<'EOF'
{"schema": 1, "owner": "powercontext", "integration": "workbuddy"}
EOF
```

Then replace `${POWERCONTEXT_PYTHON}` in
`~/.workbuddy/skills/powercontext-project-context/SKILL.md` with a shell-safe Python
executable argument. Replace `${POWERCONTEXT_SCOPE_BINDING_SCRIPT}` with a
shell-safe complete path to
`<WORKBUDDY_HOOKS_DIR>/powercontext_scope_binding.py`.

### 5. Start the Server, restart WorkBuddy, and verify

```bash
powercontext server run
```

Restart WorkBuddy so it discovers the new hook, MCP server, and Skill. Send any
prompt; the hook reports `Syncing PowerContext` while it runs. Verify the
installation with:

```bash
powercontext doctor
```

The MCP tools (`search_memory` and the Handoff tools) appear in the WorkBuddy
session when the Server is reachable.

## Understand automatic recall, Memory, and Handoff

The integration has two paths to the same Server:

- a `UserPromptSubmit` hook asks the Runtime to prepare one final, bounded
  context value before WorkBuddy analyzes the prompt, then independently
  captures the prompt as Source evidence;
- MCP gives WorkBuddy explicit tools to read and maintain Memory, plus an
  explicit Handoff workflow.

The `powercontext-project-context` Skill guides explicit work transfers. Ordinary `交接`, `交接当前工作`, or
`handoff this work` requests inspect the conversation and repository, call `handoff_current_work`, and return the
complete `handoff` member as a temporary carrier. This records the boundary Source, not a durable Handoff Revision.
The receiver can continue with `selection: "prepared"` and that exact carrier.

Only an explicit durable request such as `commit a durable handoff` or `保存持久交接里程碑` authorizes passing the
returned carrier unchanged to `commit_handoff`. A committed milestone requires a successful result with an exact
Revision. Preview or design requests remain read-only; ordinary transfer does not authorize a commit.

The Hook calls `POST /v1/context/prepare` once per prompt, requests an
8000-byte total budget, strictly validates `powercontext.prepared-context.v1`,
and injects the returned content unchanged. The Runtime labels Memory-derived
items as untrusted history, preserves exact citations, and owns final selection
and rendering. Automatically injected content and Handoffs are historical
information. WorkBuddy must still check current code, user requests, and system
instructions before acting on them.

Memory stores durable, reusable decisions, constraints, and state. A Handoff
temporarily transfers the current task to another task, session, or model. It
must be explicitly prepared, inspected, and delivered, rather than substituted
with a few Memory entries. Read
[Memory and Handoff](../workflows/memory-and-handoff.md) for the boundary.

## Control prompt capture

Prompt capture is enabled by default. Disable it before restarting WorkBuddy
when the current work must not be recorded:

```bash
export POWERCONTEXT_WORKBUDDY_CAPTURE_PROMPTS=false
```

Captured prompts become Source evidence. Turning capture on does not guarantee
automatic Memory extraction; that requires a configured generation model.
Explicit `remember_memory` calls do not require a model.

For testing only, make the hook wait for captured Source processing:

```bash
export POWERCONTEXT_WORKBUDDY_FLUSH_ON_CAPTURE=true
```

This adds inference latency to each prompt and is not the normal interactive
setting.

## Configuration

Environment variables override the hook defaults; restart WorkBuddy after
changing them.

| Variable | Purpose |
| --- | --- |
| `POWERCONTEXT_WORKBUDDY_SERVER_URL` | PowerContext server URL (default `http://127.0.0.1:8000`) |
| `POWERCONTEXT_WORKBUDDY_ALLOW_INSECURE_HTTP` | Explicitly permit non-loopback plaintext HTTP for hooks (default `false`) |
| `POWERCONTEXT_WORKBUDDY_AUTHORIZATION` | Complete authorization header, e.g. `Bearer <token>` |
| `POWERCONTEXT_WORKBUDDY_SCOPE_ID` | Explicit server-owned Scope ID |
| `POWERCONTEXT_WORKBUDDY_CAPTURE_PROMPTS` | Capture user prompts as Sources (default `true`) |
| `POWERCONTEXT_WORKBUDDY_FLUSH_ON_CAPTURE` | Flush until the captured Source is processed (testing only, default `false`) |
| `POWERCONTEXT_WORKBUDDY_REQUEST_TIMEOUT_SECONDS` | Per-request HTTP timeout (default `3.0`) |
| `POWERCONTEXT_WORKBUDDY_HTTP_BUDGET_SECONDS` | Shared wall-clock budget for one prompt (default `6.0`) |
| `POWERCONTEXT_WORKBUDDY_FLUSH_MAX_CALLS` | Maximum flush calls (default `4`) |

The hook validates its PowerContext MCP URL and derives the HTTP API base by
removing the final `/mcp` path segment. MCP URLs cannot contain credentials,
query strings, or fragments. Plain HTTP is allowed on loopback by default; non-loopback HTTP requires
`POWERCONTEXT_WORKBUDDY_ALLOW_INSECURE_HTTP=true`. Setup configures the Hook and native MCP URL, but WorkBuddy's
own MCP policy still applies. HTTPS certificate validation stays enabled. See
[Connect to a remote Server](../operate/connect-remote-server.md).

## Resolve the project scope

The Server resolves Scope for WorkBuddy in this order:

1. an explicit `POWERCONTEXT_WORKBUDDY_SCOPE_ID`;
2. a durable session binding;
3. a durable workspace binding;
4. the Server's default Scope.

Later WorkBuddy sessions in the same workspace reuse that Scope. The `powercontext-project-context` Skill's `--bind-scope`
operation persists the workspace binding in PowerContext. The workspace path is hashed only as an external binding
key; the plugin never derives a Scope ID from it.

## Connect to an authenticated local Server

Load one token from your local secret manager, then start the Server with
authentication enabled:

```bash
export POWERCONTEXT_SERVER_ACCESS_MODE=enforced
export POWERCONTEXT_SERVER_AUTH_TOKEN="$POWERCONTEXT_LOCAL_TOKEN"
powercontext server run
```

Start WorkBuddy from an environment that contains the matching complete
Authorization header:

```bash
export POWERCONTEXT_WORKBUDDY_AUTHORIZATION="Bearer $POWERCONTEXT_LOCAL_TOKEN"
```

Restart WorkBuddy after changing the variable. The prompt Hook reads this value
from the environment. `.mcp.json` stores only the
`${POWERCONTEXT_WORKBUDDY_AUTHORIZATION:-}` template, which WorkBuddy expands
from the same environment; the token itself remains outside the file. Do not put
the token in `.mcp.json` or the Server URL.

When the variable is absent or empty and Server authentication is disabled, the
plugin behaves exactly as it does by default. When Server authentication is
enabled but the header is missing or incorrect, the Hook fails open and emits an
`authentication_failed` diagnostic; MCP tools remain unavailable without
blocking the WorkBuddy session.

## Failure behavior

| Scenario | Behavior |
| --- | --- |
| Server unavailable | Hook recall and capture fail open; the prompt proceeds without injected context. MCP tools report that the service is unavailable |
| Authentication failure | Hook fails open and emits an `authentication_failed` diagnostic; MCP tools remain unavailable |
| Empty prepared context | No context is injected; the hook emits an `empty` diagnostic |
| Version mismatch | Hook fails open and emits a `version_mismatch` diagnostic |
| Invalid or oversized response | Hook fails open and emits an `invalid_response` diagnostic; nothing is injected |
| Hook timeout (30 s) | WorkBuddy continues; the hook process is stopped by the outer hook timeout |

Recall, capture, and flush fail independently. An unavailable Server never
blocks normal WorkBuddy work.

## Diagnostics

For a normal empty result or recall failure, the Hook writes one content-free
JSON diagnostic to stderr. Outcomes include `empty`, `authentication_failed`,
`version_mismatch`, `server_unavailable`, and `invalid_response`. The event
never contains the query, scope, prepared content, citation, response body, or
authorization value.

During each prompt you should see the hook's `Syncing PowerContext` status
message. Verify the whole installation with `powercontext doctor`.

## Uninstall

1. Remove the `UserPromptSubmit` PowerContext entry from `~/.workbuddy/settings.json`.
2. Remove the `powercontext` entry from `~/.workbuddy/mcp.json`.
3. Remove the hook files and the scope resolver from `<WORKBUDDY_HOOKS_DIR>`.
4. Remove `~/.workbuddy/skills/powercontext-project-context`.
5. Optionally stop the Server and delete its local data directory.

## Automatic input privacy

See [Automatic prompt privacy](index.md#automatic-prompt-privacy) for this host's capture default, disable control, credential recognition limits and independent read-only query handling. Recognized inputs are skipped for capture; accepted Source content and event identity are not rewritten.
