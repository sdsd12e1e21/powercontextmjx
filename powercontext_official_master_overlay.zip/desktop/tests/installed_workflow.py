# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""W3C WebDriver interactions with the real installed application and Server."""

from __future__ import annotations

import json
import tempfile
import time
from pathlib import Path

import httpx
from installed_boundaries import exercise_note_budget, exercise_search_limit
from installed_fixture import (
    exact_memory_text,
    fixture_compatibility_profile,
    isolated_server,
    saved_reference,
    search_reference,
)
from real_server import HarnessFailure

ELEMENT = "element-6066-11e4-a52e-4f735466cecf"
NOTE = "desktopinstalledci 中文安装后验收\n纯文本 café <script>literal</script>"


class InstalledPage:
    def __init__(self, client: httpx.Client, prefix: str) -> None:
        self.client = client
        self.prefix = prefix

    def post(self, path: str, payload: dict[str, object]):
        response = self.client.post(self.prefix + path, json=payload)
        response.raise_for_status()
        return response.json()["value"]

    def element(self, xpath: str) -> str:
        for _ in range(100):
            response = self.client.post(self.prefix + "/element", json={"using": "xpath", "value": xpath})
            if response.is_success:
                identifier = response.json()["value"][ELEMENT]
                enabled = self.client.get(self.prefix + f"/element/{identifier}/enabled")
                enabled.raise_for_status()
                if enabled.json()["value"]:
                    return identifier
            elif response.json().get("value", {}).get("error") not in {"no such element", "stale element reference"}:
                response.raise_for_status()
            time.sleep(0.2)
        raise HarnessFailure("installed_element_timeout", xpath)

    def click_element(self, identifier: str) -> None:
        # Scroll through the browser before a real pointer click. WebDriver's
        # automatic edge alignment can put the target behind a wrapping sticky bar.
        self.observe(
            "arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});",
            [{ELEMENT: identifier}],
        )
        self.post(f"/element/{identifier}/click", {})

    def click(self, xpath: str) -> None:
        self.click_element(self.element(xpath))

    def button(self, text: str) -> None:
        self.click(f"//button[normalize-space(.)='{text}']")

    def field(self, label: str, tag: str = "input") -> str:
        return self.element(
            f"//label[normalize-space(text())='{label}' or span[normalize-space(.)='{label}']]//{tag}"
            f" | //{tag}[@aria-label='{label}']"
        )

    def type(self, label: str, value: str, tag: str = "input") -> None:
        self.post(f"/element/{self.field(label, tag)}/value", {"text": value})

    def observe(self, script: str, args: list[object] | None = None):
        return self.post("/execute/sync", {"script": script, "args": args or []})

    def wait(self, script: str, args: list[object] | None = None) -> None:
        for _ in range(100):
            if self.observe(script, args):
                return
            time.sleep(0.2)
        raise HarnessFailure("installed_observation_timeout")

    def wait_text(self, text: str) -> None:
        self.wait("return document.body.innerText.includes(arguments[0]);", [text])

    def confirm(self, message: str, *, accept: bool) -> None:
        """Check and answer the application's dialog with a real WebDriver click."""
        dialog_xpath = "//div[@role='alertdialog' and @aria-modal='true']"
        dialog = self.element(dialog_xpath)
        if (
            self.observe(
                "return document.getElementById(arguments[0].getAttribute('aria-describedby'))?.textContent;",
                [{ELEMENT: dialog}],
            )
            != message
        ):
            raise HarnessFailure("installed_confirmation_message_mismatch", message)
        action = "确认" if accept else "取消"
        self.click(f"{dialog_xpath}//button[normalize-space(.)='{action}']")
        # A confirmed dirty editor can immediately open a second confirmation
        # (for example, removing its profile). Wait only for this prompt to leave.
        self.wait(
            """return ![...document.querySelectorAll('[role=alertdialog]')].some(dialog =>
              document.getElementById(dialog.getAttribute('aria-describedby'))?.textContent === arguments[0]);""",
            [message],
        )

    def profile(self, name: str) -> None:
        self.click(
            f"//ul[@class='profile-list']//span[@class='profile-name'][normalize-space(.)='{name}']/ancestor::button"
        )

    def open_connection_menu(self) -> None:
        self.click("//div[contains(@class,'topbar')]/div[contains(@class,'menu-wrap')][1]/button")

    def activate(self, name: str) -> None:
        self.button("使用此连接")
        self.element(
            f"//ul[@class='profile-list']/li[.//span[@class='profile-name'][normalize-space(.)='{name}']]//span[contains(@class,'badge')]"
        )
        self.button("记忆")

    def connect(self, name: str, endpoint: str) -> None:
        self.button("连接")
        self.type("连接名称", name)
        self.type("Server 地址", endpoint)
        compatibility = fixture_compatibility_profile()
        self.click(f"//label[normalize-space(text())='已验证兼容配置']/select//option[@value='{compatibility}']")
        self.button("保存配置")
        self.activate(name)

    def select_scope(self, scope_id: str) -> None:
        self.click("//div[@class='topbar-group']/button")
        self.type("按范围标题查找", "Desktop installed CI")
        self.button("查找范围")
        self.click(f"//ul[@class='scope-list']/li[code[normalize-space(.)='{scope_id}']]/button")
        self.wait("return !document.querySelector('[role=dialog]');")
        self.wait(
            "return document.querySelector('.topbar-group button')?.textContent.includes('Desktop installed CI');"
        )

    def expect_empty_context(self) -> None:
        observed = self.observe("""return {
          reader: !!document.querySelector('.reader'),
          hits: document.querySelectorAll('.memory-hits li').length,
          draft: document.querySelector('.memory-workspace textarea')?.value,
          query: document.querySelector('.search-input input')?.value
        };""")
        if observed != {"reader": False, "hits": 0, "draft": "", "query": ""}:
            raise HarnessFailure("installed_previous_context_not_cleared")

    def search_read(self, text: str, keyword: str = "desktopinstalledci") -> dict[str, object]:
        self.type("关键词搜索", keyword)
        self.button("搜索")
        self.button("阅读精确版本")
        self.wait_text("记忆详情")
        if not self.observe("""return [...document.querySelectorAll('.memory-hits li')].every(hit => {
          const button = hit.querySelector('button').getBoundingClientRect();
          const card = hit.closest('section').getBoundingClientRect();
          return button.left >= card.left && button.right <= card.right
            && button.top >= card.top && button.bottom <= card.bottom;
        }) && (() => {
          const reader = document.querySelector('.reader');
          const style = getComputedStyle(reader);
          return reader.getBoundingClientRect().height <= Math.min(760, innerHeight * 0.75) + 1
            && style.overflowY === 'auto' && reader.scrollWidth <= reader.clientWidth;
        })();"""):
            raise HarnessFailure("installed_memory_layout_overflow")
        if self.observe("return document.querySelector('.reader > .plain-text')?.textContent;") != text:
            raise HarnessFailure("installed_exact_body_mismatch")
        return json.loads(self.observe("return document.querySelector('.reader pre')?.textContent;"))

    def paste(self) -> str:
        field = self.field("记忆内容", "textarea")
        self.click_element(field)
        self.post(f"/element/{field}/value", {"text": "\ue009v\ue000"})
        for _ in range(100):
            value = self.observe("return arguments[0].value;", [{ELEMENT: field}])
            if value:
                return value
            time.sleep(0.2)
        raise HarnessFailure("installed_clipboard_paste_timeout")

    def clear_note(self) -> None:
        field = self.field("记忆内容", "textarea")
        # Keys preserve React input events and do not invoke product internals.
        self.post(f"/element/{field}/value", {"text": "\ue009a\ue000\ue003"})
        if self.observe("return arguments[0].value;", [{ELEMENT: field}]) != "":
            raise HarnessFailure("installed_note_not_cleared")


def exercise_memory(client: httpx.Client, prefix: str) -> dict[str, object]:
    page = InstalledPage(client, prefix)
    with isolated_server() as (server, scope_id, wheel_digest):
        page.connect("Desktop CI synthetic", str(server.base_url).rstrip("/"))
        page.select_scope(scope_id)
        exercise_note_budget(page, server, scope_id)
        page.type("记忆内容", NOTE, "textarea")
        before_submit = server.post(
            "/v1/memory/search", json={"scope_id": scope_id, "query": "desktopinstalledci", "mode": "fts", "limit": 10}
        )
        before_submit.raise_for_status()
        if before_submit.json()["hits"]:
            raise HarnessFailure("installed_enter_submitted_without_button")
        page.button("保存")
        page.wait_text("保存成功。")
        reference = page.search_read(NOTE)
        if exact_memory_text(server, scope_id, reference) != NOTE:
            raise HarnessFailure("installed_independent_exact_read_mismatch")
        page.button("复制正文")
        page.wait_text("已复制")
        if page.paste() != NOTE:
            raise HarnessFailure("installed_body_clipboard_mismatch")
        page.clear_note()
        page.button("复制精确引用")
        if json.loads(page.paste()) != reference:
            raise HarnessFailure("installed_reference_clipboard_mismatch")
        page.clear_note()
        exercise_search_limit(page, server, scope_id)
        exercise_connection_isolation(page, server, scope_id, reference)
        exercise_late_save(page)
        exercise_unknown_write(page)
        return {
            "serverWheelSha256": wheel_digest,
            "mode": "anonymous loopback SQLite, no model",
            "explicitConnectionAndScope": True,
            "saveSearchExactRead": True,
            "independentServerExactRead": True,
            "bodyAndReferenceClipboardPaste": True,
            "twoServerConnectionIsolation": True,
            "disconnectReconnectClearsContent": True,
            "unsavedDraftCancelAndDiscard": True,
            "inactiveProfileRemovalPreservesServerData": True,
            "enterDoesNotSubmit": True,
            "rawUtf8BudgetBoundary": True,
            "emptyAndCappedSearchPresentation": True,
            "committedLostResponseUnknownWithoutReplay": True,
            "lateSavePreservesNewScopeDraft": True,
        }


def current_unchanged_entry(server: httpx.Client, scope: str, original: dict[str, object]) -> dict[str, object]:
    current = server.post(
        "/v1/memory/search",
        json={"scope_id": scope, "query": "desktopinstalledci", "mode": "fts", "limit": 10},
    )
    current.raise_for_status()
    current_hits = current.json()["hits"]
    if len(current_hits) != 1:
        raise HarnessFailure("installed_original_server_search_ambiguous")
    current_reference_a = search_reference(current_hits[0])
    if current_reference_a != original:
        raise HarnessFailure("installed_original_reference_changed")
    return current_reference_a


def exercise_connection_isolation(
    page: InstalledPage,
    server_a: httpx.Client,
    scope_a: str,
    reference_a: dict[str, object],
) -> None:
    current_reference_a = current_unchanged_entry(server_a, scope_a, reference_a)
    text_b = "desktopinstalledci B 独立服务中的另一条记忆"
    with isolated_server() as (server_b, scope_b, _):
        seeded = server_b.post("/v1/memory/remember", json={"scope_id": scope_b, "kind": "note", "text": text_b})
        seeded.raise_for_status()
        reference_b = saved_reference(seeded.json())
        page.connect("Desktop CI B", str(server_b.base_url).rstrip("/"))
        page.expect_empty_context()
        page.select_scope(scope_b)
        if page.search_read(text_b) != reference_b:
            raise HarnessFailure("installed_second_server_reference_mismatch")
        draft = "desktopunsavedci 不应写入的草稿"
        page.type("记忆内容", draft, "textarea")
        page.open_connection_menu()
        page.button("断开桌面连接")
        page.confirm("丢弃尚未保存的输入？", accept=False)  # noqa: RUF001 - exact localized UI
        if page.observe("return document.querySelector('.memory-workspace textarea')?.value;") != draft:
            raise HarnessFailure("installed_cancel_disconnect_lost_draft")
        if page.observe("return document.querySelector('.reader > .plain-text')?.textContent;") != text_b:
            raise HarnessFailure("installed_cancel_disconnect_changed_reader")
        page.open_connection_menu()
        page.button("断开桌面连接")
        page.confirm("丢弃尚未保存的输入？", accept=True)  # noqa: RUF001 - exact localized UI
        page.wait_text("尚未连接")
        page.expect_empty_context()
        page.button("连接")
        page.profile("Desktop CI synthetic")
        page.activate("Desktop CI synthetic")
        page.expect_empty_context()
        page.select_scope(scope_a)
        if page.search_read(NOTE) != current_reference_a:
            raise HarnessFailure("installed_reconnected_reference_mismatch")
        page.button("连接")
        page.profile("Desktop CI B")
        page.button("移除连接")
        page.confirm("只移除此桌面配置和自有凭据，不停止服务或删除业务数据。继续？", accept=True)  # noqa: RUF001 - exact localized UI
        page.wait("""return ![...document.querySelectorAll('.profile-name')].some(
          name => name.textContent.trim() === 'Desktop CI B');""")
        for server, scope, reference, expected in (
            (server_a, scope_a, reference_a, NOTE),
            (server_b, scope_b, reference_b, text_b),
        ):
            if exact_memory_text(server, scope, reference) != expected:
                raise HarnessFailure("installed_profile_operation_changed_server_data")
        page.button("记忆")
        if page.search_read(NOTE) != current_reference_a:
            raise HarnessFailure("installed_inactive_profile_removal_changed_active_connection")


def exercise_unknown_write(page: InstalledPage) -> None:
    note = "desktoplostuici 已提交但响应丢失的中文记忆"
    with tempfile.TemporaryDirectory(prefix="desktop-ui-response-loss-") as directory:
        counter = Path(directory) / "remember-count"
        counter.write_text("0", encoding="utf-8")
        with isolated_server(response_loss_counter=counter) as (server, scope, _):
            page.connect("Desktop CI response loss", str(server.base_url).rstrip("/"))
            page.select_scope(scope)
            page.type("记忆内容", note, "textarea")
            page.button("保存")
            page.wait_text("提交结果未知。")
            if page.observe("return document.querySelector('.memory-workspace textarea')?.value;") != note:
                raise HarnessFailure("installed_unknown_write_lost_draft")
            reference = page.search_read(note, "desktoplostuici")
            matches = server.post(
                "/v1/memory/search",
                json={
                    "scope_id": scope,
                    "query": "desktoplostuici",
                    "mode": "fts",
                    "limit": 10,
                },
            )
            matches.raise_for_status()
            hits = matches.json()["hits"]
            if len(hits) != 1 or search_reference(hits[0]) != reference or counter.read_text(encoding="utf-8") != "1":
                raise HarnessFailure("installed_unknown_write_replayed_or_missing")
            page.clear_note()


def exercise_late_save(page: InstalledPage) -> None:
    with tempfile.TemporaryDirectory(prefix="desktop-late-save-") as directory:
        gate = Path(directory) / "hold-response"
        gate.touch()
        with isolated_server(response_gate=gate) as (server, scope_a, _):
            response = server.post(
                "/v1/scopes",
                json={
                    "title": "Desktop installed CI B",
                    "summary": "Late save isolation",
                    "idempotency_key": "desktop-late-scope-b",
                },
            )
            response.raise_for_status()
            scope_b = response.json()["scope_id"]
            page.connect("Desktop CI late save", str(server.base_url).rstrip("/"))
            page.select_scope(scope_a)
            page.type("记忆内容", "desktoplatesave Original scope note", "textarea")
            page.button("保存")
            for _ in range(100):
                if Path(str(gate) + ".ready").exists():
                    break
                time.sleep(0.05)
            else:
                raise HarnessFailure("installed_late_save_not_dispatched")
            page.click("//div[@class='topbar-group']/button")
            page.button("查找范围")
            page.click(f"//ul[@class='scope-list']/li[code[normalize-space(.)='{scope_b}']]/button")
            page.confirm("丢弃尚未保存的输入？", accept=True)  # noqa: RUF001 - exact localized UI
            page.wait("return !document.querySelector('[role=dialog]');")
            draft = "new scope unsaved draft"
            page.type("记忆内容", draft, "textarea")
            gate.unlink()
            # This is shown only after the old form refreshes the native write record.
            page.wait_text("连接或范围已改变，旧正文已隐藏。")  # noqa: RUF001 - exact localized UI
            page.button("总览")
            page.confirm("丢弃尚未保存的输入？", accept=False)  # noqa: RUF001 - exact localized UI
            if page.observe("return document.querySelector('.memory-workspace textarea')?.value;") != draft:
                raise HarnessFailure("installed_late_save_lost_new_draft")
            original = server.post(
                "/v1/memory/search",
                json={
                    "scope_id": scope_a,
                    "query": "desktoplatesave",
                    "mode": "fts",
                    "limit": 10,
                },
            )
            original.raise_for_status()
            if len(original.json()["hits"]) != 1:
                raise HarnessFailure("installed_late_save_original_target_missing")
            page.clear_note()
