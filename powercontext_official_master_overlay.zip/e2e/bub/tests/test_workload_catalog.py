# Copyright (c) 2026 OceanBase.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from pathlib import Path

import pytest

from powercontext_e2e.catalog import RecallProbeSpec, load_tasks, select_tasks
from powercontext_e2e.runner import group_tasks


def test_workloads_can_be_selected_by_multiple_ids_or_category() -> None:
    repository = Path(__file__).resolve().parents[3]
    tasks = load_tasks(repository / "e2e" / "bub" / "tasks")

    assert [task.id for task in tasks] == [
        "project-database-decision",
        "failure-policy-timeout",
        "failure-policy-followup",
        "locomo-multihop-football",
        "locomo-open-pastries",
        "locomo-support-group",
        "locomo-temporal-banker",
        "terminal-bench-db-wal-recovery",
    ]
    assert {task.execution.type for task in tasks} == {"bub"}
    assert {task.id for task in tasks if task.execution.model} == {"terminal-bench-db-wal-recovery"}

    selected_ids = select_tasks(
        tasks,
        ids=("locomo-support-group", "terminal-bench-db-wal-recovery"),
    )
    acceptance = select_tasks(tasks, categories=("acceptance",))

    assert [task.id for task in selected_ids] == [
        "locomo-support-group",
        "terminal-bench-db-wal-recovery",
    ]
    assert [task.id for task in acceptance] == [
        "project-database-decision",
        "failure-policy-timeout",
        "failure-policy-followup",
        "locomo-multihop-football",
        "locomo-open-pastries",
        "locomo-support-group",
        "locomo-temporal-banker",
    ]
    assert [group.tasks for group in group_tasks(acceptance)] == [
        tuple(task for task in acceptance if "batch:acceptance" in task.categories),
        tuple(task for task in acceptance if "batch:locomo" in task.categories),
    ]


def test_batch_category_cannot_escape_the_runtime_dataset() -> None:
    repository = Path(__file__).resolve().parents[3]
    task = load_tasks(repository / "e2e" / "bub" / "tasks" / "locomo-support-group.yaml")[0]
    task = task.model_copy(update={"categories": (*task.categories[:-1], "batch:x/../../evil")})

    with pytest.raises(ValueError, match="valid batch category"):
        group_tasks((task,))


def test_recall_probe_manifest_accepts_forbidden_context() -> None:
    probe = RecallProbeSpec.model_validate({
        "id": "database-decision",
        "query": "Which database decision is current?",
        "expected_context": ["OceanBase"],
        "forbidden_context": ["SQLite"],
    })

    assert probe.forbidden_context == ("SQLite",)


@pytest.mark.parametrize("field_name", ["expected_context", "forbidden_context"])
def test_recall_probe_manifest_rejects_blank_context_fragments(field_name: str) -> None:
    payload = {
        "id": "database-decision",
        "query": "Which database decision is current?",
        field_name: ["  "],
    }

    with pytest.raises(ValueError, match=f"{field_name} fragments must be nonblank"):
        RecallProbeSpec.model_validate(payload)


def test_recall_probe_manifest_rejects_impossible_context_contract() -> None:
    with pytest.raises(ValueError, match="forbidden_context cannot be contained in expected_context"):
        RecallProbeSpec.model_validate({
            "id": "database-decision",
            "query": "Which database decision is current?",
            "expected_context": ["SQLite"],
            "forbidden_context": ["sql"],
        })
